import { useEffect, useMemo, useState } from 'react';
import { CheckCircle2, Download, LoaderCircle, MoreVertical, Share2, Smartphone, X } from 'lucide-react';
import {
  detectPwaEnvironment,
  getDeferredInstallPrompt,
  installGuideSteps,
  isStandalonePwa,
  promptPwaInstall,
} from '../lib/pwaInstall';

const SEEN_KEY = 'tum-pwa-install-guide-v4';

type InstallPhase = 'idle' | 'installing' | 'installed';

function browserLabel(browser: ReturnType<typeof detectPwaEnvironment>['browser']) {
  return browser === 'safari' ? 'Safari'
    : browser === 'chrome' ? 'Chrome'
      : browser === 'samsung' ? 'Samsung Internet'
        : browser === 'edge' ? 'Edge'
          : browser === 'firefox' ? 'Firefox'
            : browser === 'opera' ? 'Opera'
              : 'Navegador';
}

export default function PwaInstallGuide({ runtimePlatform }: { runtimePlatform: string }) {
  const environment = useMemo(() => detectPwaEnvironment(), []);
  const [open, setOpen] = useState(false);
  const [canPrompt, setCanPrompt] = useState(() => Boolean(getDeferredInstallPrompt()));
  const [phase, setPhase] = useState<InstallPhase>('idle');

  useEffect(() => {
    if (runtimePlatform !== 'web' || !environment.mobile || isStandalonePwa()) return;

    const onReady = () => setCanPrompt(true);
    const onInstalled = () => {
      localStorage.setItem(SEEN_KEY, 'installed');
      setPhase('installed');
      window.setTimeout(() => setOpen(false), 1300);
    };

    window.addEventListener('tum:pwa-install-ready', onReady);
    window.addEventListener('tum:pwa-installed', onInstalled);

    const seen = localStorage.getItem(SEEN_KEY);
    const timer = window.setTimeout(() => {
      if (!seen && !isStandalonePwa()) setOpen(true);
    }, 1200);

    return () => {
      window.clearTimeout(timer);
      window.removeEventListener('tum:pwa-install-ready', onReady);
      window.removeEventListener('tum:pwa-installed', onInstalled);
    };
  }, [environment.mobile, runtimePlatform]);

  if (runtimePlatform !== 'web' || !environment.mobile || isStandalonePwa() || !open) return null;

  const steps = installGuideSteps(environment.os, environment.browser);
  const deviceLabel = environment.os === 'ios' ? 'iPhone / iPad' : environment.os === 'android' ? 'Android' : 'Celular';

  const dismiss = () => {
    if (phase === 'installing') return;
    localStorage.setItem(SEEN_KEY, 'seen');
    setOpen(false);
  };

  const installNow = async () => {
    if (phase !== 'idle') return;

    // Troca a interface imediatamente para a tela de carregamento. O prompt nativo
    // do navegador aparece por cima e, quando aceito, mantemos o loading até o
    // evento appinstalled confirmar que a instalação terminou de verdade.
    setPhase('installing');

    try {
      const result = await promptPwaInstall();

      if (result === 'dismissed') {
        setPhase('idle');
        return;
      }

      if (result === 'unavailable') {
        setCanPrompt(false);
        setPhase('idle');
      }
      // accepted: NÃO fechamos aqui. O evento tum:pwa-installed fará isso.
    } catch {
      setPhase('idle');
    }
  };

  if (phase === 'installing' || phase === 'installed') {
    const finished = phase === 'installed';

    return (
      <div className="fixed inset-0 z-[1000] flex items-center justify-center bg-black/80 px-4 py-4 backdrop-blur-md">
        <div
          className="w-full max-w-[340px] rounded-[28px] border border-white/10 bg-tum-dark-2 px-6 py-7 text-center shadow-2xl"
          role="status"
          aria-live="polite"
        >
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-[22px] bg-tum-yellow text-black shadow-[0_10px_35px_rgba(250,204,21,0.28)]">
            {finished ? <CheckCircle2 size={34} strokeWidth={2.7} /> : <LoaderCircle size={34} className="animate-spin" strokeWidth={2.7} />}
          </div>

          <h2 className="mt-5 text-xl font-black text-white">
            {finished ? 'TUM instalado!' : 'Instalando o TUM…'}
          </h2>
          <p className="mx-auto mt-2 max-w-[280px] text-sm font-semibold leading-5 text-white/60">
            {finished
              ? 'Pronto. Agora você pode abrir o TUM pelo ícone criado na sua tela inicial.'
              : 'Aguarde o navegador concluir. Não feche esta tela durante a instalação.'}
          </p>

          {!finished && (
            <div className="mt-5 overflow-hidden rounded-full bg-white/10 p-1">
              <div className="h-1.5 w-1/2 animate-pulse rounded-full bg-tum-yellow" />
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[1000] flex items-end justify-center bg-black/70 px-2.5 pb-[max(0.5rem,env(safe-area-inset-bottom))] pt-2.5 backdrop-blur-sm sm:items-center">
      <div className="w-full max-w-[390px] overflow-hidden rounded-[26px] border border-white/10 bg-tum-dark-2 shadow-2xl">
        <div className="relative border-b border-black/10 bg-tum-yellow px-4 pb-3.5 pt-3.5 text-black">
          <button
            type="button"
            onClick={dismiss}
            className="absolute right-3 top-3 flex h-8 w-8 items-center justify-center rounded-full bg-black/10 transition active:scale-95"
            aria-label="Fechar instruções de instalação"
          >
            <X size={17} />
          </button>

          <div className="flex items-center gap-3 pr-9">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-black text-tum-yellow shadow-md">
              <Smartphone size={21} />
            </div>
            <div className="min-w-0">
              <h2 className="text-[17px] font-black leading-5">Adicione o TUM à tela inicial</h2>
              <p className="mt-0.5 text-[11px] font-bold leading-4 text-black/60">
                {deviceLabel} · {browserLabel(environment.browser)} · abre como aplicativo em tela cheia
              </p>
            </div>
          </div>
        </div>

        <div className="px-3.5 pb-3.5 pt-3">
          {canPrompt && environment.os === 'android' && (
            <button
              type="button"
              onClick={() => void installNow()}
              className="mb-3 flex w-full items-center justify-center gap-3 rounded-2xl border-2 border-yellow-200 bg-tum-yellow px-4 py-3.5 text-black shadow-[0_8px_28px_rgba(250,204,21,0.30)] transition active:scale-[0.985]"
            >
              <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-black text-tum-yellow">
                <Download size={18} strokeWidth={3} />
              </span>
              <span className="text-left">
                <span className="block text-[15px] font-black leading-4">INSTALAR TUM</span>
                <span className="mt-0.5 block text-[10px] font-extrabold uppercase tracking-[0.08em] text-black/55">Adicionar à tela inicial</span>
              </span>
            </button>
          )}

          <div className="mb-2 flex items-center gap-1.5 text-[10px] font-black uppercase tracking-[.13em] text-white/35">
            {environment.os === 'ios' ? <Share2 size={13} /> : <MoreVertical size={13} />}
            Como instalar
          </div>

          <div className="space-y-1.5">
            {steps.map((step, index) => (
              <div key={step} className="flex items-start gap-2 rounded-xl border border-white/10 bg-white/[.035] px-2.5 py-2">
                <div className="mt-px flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-tum-yellow text-[10px] font-black text-black">
                  {index + 1}
                </div>
                <p className="text-[11px] font-semibold leading-[15px] text-white/75">{step}</p>
              </div>
            ))}
          </div>

          <div className="mt-2.5 flex items-start gap-2 rounded-xl border border-emerald-400/15 bg-emerald-400/[.07] px-2.5 py-2 text-[10px] font-semibold leading-[14px] text-emerald-100/75">
            <CheckCircle2 size={14} className="mt-px shrink-0 text-emerald-300" />
            Depois de instalar, abra pelo ícone do TUM. Ele ficará em tela cheia, sem a barra do navegador.
          </div>

          <button
            type="button"
            onClick={dismiss}
            className="mt-2.5 w-full rounded-xl border border-white/10 py-2.5 text-xs font-black text-white/85 active:bg-white/5"
          >
            AGORA NÃO
          </button>
        </div>
      </div>
    </div>
  );
}
